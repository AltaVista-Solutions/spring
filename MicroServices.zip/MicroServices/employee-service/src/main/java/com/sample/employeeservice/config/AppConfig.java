package com.sample.employeeservice.config;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.sample.employeeservice.services.*;

@Configuration
public class AppConfig {
	
	@Bean
	public EmployeeService getempserv()
	{
		return new EmployeeServiceImpl();
	}
	
	@Bean
	public ModelMapper getmapper()
	{
		return new ModelMapper();
	}
	
	@Bean
	public RestTemplate getRestTemplate()
	{
		return new RestTemplate();
	}
	
	
}
