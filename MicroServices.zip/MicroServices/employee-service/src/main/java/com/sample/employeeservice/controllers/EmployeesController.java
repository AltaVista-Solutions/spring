package com.sample.employeeservice.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.sample.employeeservice.entity.Employee;
import com.sample.employeeservice.responses.AddressResponse;
import com.sample.employeeservice.responses.EmployeeResponse;
import com.sample.employeeservice.services.EmployeeService;

@RestController
@RequestMapping("/employees/")
public class EmployeesController 
{
	@Autowired
	private EmployeeService serv;
	
	@Autowired
	private ModelMapper modelmapper;
	
	@Autowired
	private RestTemplate rest;
	
	@Value("${addressservice.base.url}")
	private String BaseURL;
	
	@GetMapping("/{id}")
	public ResponseEntity<EmployeeResponse> getById(@PathVariable int id)
	{
		Employee emp=serv.getEmployeeById(id);
		EmployeeResponse empRes=modelmapper.map(emp, EmployeeResponse.class);
		
		String url=BaseURL+"/address/"+id;
		AddressResponse addres= rest.getForObject(url, AddressResponse.class);
		empRes.setAddressResponse(addres);
		
		return ResponseEntity.status(HttpStatus.OK).body(empRes);
	}
}
