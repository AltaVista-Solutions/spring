package com.sample.employeeservice.responses;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EmployeeResponse {
	private int id;
	private String name;
	private int age;
	private String baselocation;
	private String designation;
	private AddressResponse addressResponse;
}
