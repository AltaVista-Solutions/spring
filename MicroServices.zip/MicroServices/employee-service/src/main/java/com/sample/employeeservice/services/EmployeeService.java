package com.sample.employeeservice.services;

import com.sample.employeeservice.entity.Employee;

public interface EmployeeService {
	public Employee getEmployeeById(int id);
}
