package com.sample.employeeservice.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.sample.employeeservice.entity.Employee;
import com.sample.employeeservice.repository.EmployeeRepository;

public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository repo;
	
	@Override
	public Employee getEmployeeById(int id) {
		return repo.findById(id).get();		
	}

}
