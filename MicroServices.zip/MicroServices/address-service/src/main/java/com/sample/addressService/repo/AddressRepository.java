package com.sample.addressService.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sample.addressService.entity.Address;

public interface AddressRepository extends JpaRepository<Address, Integer> {

	@Query(nativeQuery = true,value="select a.aid,a.lane1,a.lane2,a.city,a.pin from employees e join Address a on e.id=a.eid where e.id=:id")
	Address findByEmpId(@Param("id") int id);
}
