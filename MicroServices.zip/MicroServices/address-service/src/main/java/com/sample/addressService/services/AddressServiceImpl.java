package com.sample.addressService.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.sample.addressService.entity.Address;
import com.sample.addressService.repo.AddressRepository;

public class AddressServiceImpl implements AddressService {

	@Autowired
	private AddressRepository repo;
	
	
	@Override
	public Address GetEmployeeAddressByEmpId(int id) {
		return repo.findByEmpId(id);
	}

}
