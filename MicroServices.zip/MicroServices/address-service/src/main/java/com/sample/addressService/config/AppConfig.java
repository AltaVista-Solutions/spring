package com.sample.addressService.config;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sample.addressService.services.AddressService;
import com.sample.addressService.services.AddressServiceImpl;

@Configuration
public class AppConfig {
	
	@Bean
	public AddressService GetAddressServ()
	{
		return new AddressServiceImpl();
	}
	
	@Bean
	public ModelMapper getmapper()
	{
		return new ModelMapper();
	}
	

}
