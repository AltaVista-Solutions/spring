package com.sample.addressService.services;

import com.sample.addressService.entity.Address;

public interface AddressService {
	
	Address GetEmployeeAddressByEmpId(int id); 

}
