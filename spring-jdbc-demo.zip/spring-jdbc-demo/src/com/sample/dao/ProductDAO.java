package com.sample.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.sample.mappers.ProductRowMapper;
import com.sample.models.Product;

@Component
public class ProductDAO 
{
	private final JdbcTemplate jdbcTemplate;

	@Autowired
	public ProductDAO(JdbcTemplate jdbcTemplate) {
		super();
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public void AddProduct(Product prod )
	{
		String query="insert into product(id,name,price)values(?,?,?)";
		int rowcount=jdbcTemplate.update(query,prod.getId(),prod.getName(),prod.getPrice());
		System.out.println(rowcount+" Record(s) Inserted Successfully!");
	}
	
	public List<Product> getAllProducts()
	{
		String query="select * from product";
		List<Product> prods=jdbcTemplate.query(query, new ProductRowMapper());
		System.out.println("---------------------------");
		System.out.println("Rows:"+prods.size());
		System.out.println("---------------------------");
		return prods;
	}
	
	public void UpdateProduct(Product prod )
	{
		String query="update product set name=?,price=? where id=?";
		int rowcount=jdbcTemplate.update(query,prod.getName(),prod.getPrice(),prod.getId());
		System.out.println(rowcount+" Record(s) Updated Successfully!");
	}
	
	public void DeleteProduct(int id)
	{
		String query="delete from product where id=?";
		int rowcount=jdbcTemplate.update(query,id);
		System.out.println(rowcount+" Record(s) Deleted Successfully!");
	}
	
}
