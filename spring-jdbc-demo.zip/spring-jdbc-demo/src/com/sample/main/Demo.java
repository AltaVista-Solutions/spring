package com.sample.main;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sample.config.AppConfig;
import com.sample.dao.ProductDAO;
import com.sample.models.Product;

public class Demo {

	public static void Insert()
	{
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		ProductDAO dao=(ProductDAO)context.getBean(ProductDAO.class);
		
		Scanner sc=new Scanner(System.in);
		
		Product prod=new Product();
		System.out.println("Enter Id:");
		prod.setId(sc.nextInt());
		System.out.println("Enter Name:");
		prod.setName(sc.next());
		System.out.println("Enter Price:");
		prod.setPrice(sc.nextDouble());
		dao.AddProduct(prod);
	}
	public static void GetData()
	{
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		ProductDAO dao=(ProductDAO)context.getBean(ProductDAO.class);
		List<Product> prods=dao.getAllProducts();
		for(Product prod:prods)
		{
			System.out.println("Id:"+prod.getId());
			System.out.println("Name:"+prod.getName());
			System.out.println("Price:"+prod.getPrice());
			System.out.println("---------------------------");
		}
	}
	public static void Update()
	{
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		ProductDAO dao=(ProductDAO)context.getBean(ProductDAO.class);
		
		Scanner sc=new Scanner(System.in);
		
		Product prod=new Product();
		System.out.println("Enter Id:");
		prod.setId(sc.nextInt());
		System.out.println("Enter Name:");
		prod.setName(sc.next());
		System.out.println("Enter Price:");
		prod.setPrice(sc.nextDouble());
		dao.UpdateProduct(prod);
	}
	
	public static void Delete()
	{
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		ProductDAO dao=(ProductDAO)context.getBean(ProductDAO.class);
		
		Scanner sc=new Scanner(System.in);		
		
		System.out.println("Enter Id:");
		int id=sc.nextInt();
		dao.DeleteProduct(id);
	}
	
	public static void main(String[] args) {
		Delete();
	}

}
