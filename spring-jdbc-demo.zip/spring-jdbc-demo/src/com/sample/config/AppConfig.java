package com.sample.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.sample.dao.ProductDAO;

@Configuration
public class AppConfig {
	
	@Bean
	public DataSource getdatasource()
	{
		DriverManagerDataSource datasource= new DriverManagerDataSource();
		datasource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		datasource.setUrl("jdbc:mysql://localhost:3306/demo");
		datasource.setUsername("root");
		datasource.setPassword("123456");
		return datasource;
	}
	
	@Bean
	public ProductDAO getProductDAO()
	{
		return new ProductDAO(new JdbcTemplate(getdatasource()));
	}
}
