create database demo;

use demo;
create table product
(
  id int,
  name varchar(20),
  price double
);

select * from product;