package com.sample.springMvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sample.springMvc.models.Product;

@Controller
public class HomeController {

	public static List<Product> productlist=new ArrayList<Product>();
	static
	{
		productlist.add(new Product(101, "Test Product-1", 50000));
		productlist.add(new Product(102, "Test Product-2", 65000));
		productlist.add(new Product(103, "Test Product-3", 32000));
		productlist.add(new Product(104, "Test Product-4", 44000));
		productlist.add(new Product(105, "Test Product-5", 36000));
	}
	
	@RequestMapping(value="/",method = RequestMethod.GET)
	public ModelAndView PrintData() 
	{
		ModelAndView mav=new ModelAndView("home");
		mav.addObject("products",productlist);
		return mav;
	}
	
	@RequestMapping(value="/add",method = RequestMethod.GET)
	public String AddProduct()
	{
		return "add";
	}
	
	@RequestMapping(value="/add",method = RequestMethod.POST)
	public String AddProduct(@ModelAttribute("product") Product prod)
	{
		//System.out.println(prod);
		productlist.add(prod);
		return "redirect:/";
	}
	
	private Product getProductById(int id)
	{
		for(Product prod:productlist)
		{
			if(prod.getId()==id)
			{
				return prod;
			}
		}
		return null;
	}
	
	@RequestMapping(value="/delete/{id}",method = RequestMethod.GET)
	public String DeleteProduct(@PathVariable int id)
	{
		productlist.remove(getProductById(id));
		return "redirect:/";
	}
	
	@RequestMapping(value="/edit/{id}",method = RequestMethod.GET)
	public ModelAndView Edit(@PathVariable int id)
	{
		ModelAndView mav=new ModelAndView("edit");
		mav.addObject("product",getProductById(id));
		return mav;
	}
	
	@RequestMapping(value="/edit/{id}",method = RequestMethod.POST)
	public String Edit(@PathVariable int id,@ModelAttribute("product") Product prod)
	{
		for(Product pr:productlist)
		{
			if(pr.getId()==prod.getId())
			{
				pr.setName(prod.getName());
				pr.setPrice(prod.getPrice());
				break;
			}
		}
		return "redirect:/";
	}
	
}
