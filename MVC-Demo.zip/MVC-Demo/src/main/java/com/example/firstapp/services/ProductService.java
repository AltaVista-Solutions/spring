package com.example.firstapp.services;

import java.util.*;

import com.example.firstapp.models.*;

public interface ProductService 
{
	Product addProduct(Product prod);
	Product updateProduct(Product prod);
	void deleteProduct(Product prod);
	Product getProductById(int id);
	List<Product> getAllProducts();
}
