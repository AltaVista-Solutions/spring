package com.example.firstapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.firstapp.services.ProductService;
import com.example.firstapp.services.ProductServiceImpl;

@Configuration
public class AppConfig {

	@Bean
	public ProductService getProdServ()
	{
		return new ProductServiceImpl();
	}
}
