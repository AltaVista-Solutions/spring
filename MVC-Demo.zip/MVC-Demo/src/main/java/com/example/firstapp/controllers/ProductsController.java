package com.example.firstapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.firstapp.models.Product;
import com.example.firstapp.services.ProductService;

@Controller
public class ProductsController {

	@Autowired
	private ProductService serv;
	
	
	@GetMapping("/")
	private String getProducts(Model model)
	{
		List<Product> prods=serv.getAllProducts();
		model.addAttribute("products",prods);
		return "home";
	}
	
	@GetMapping("/add")
	private String addProduct()
	{
		return "add";
	}
	
	@PostMapping("/add")
	private String addProduct(Product Prod)
	{
		serv.addProduct(Prod);
		return "redirect:/";
	}
	
	@GetMapping("/delete/{id}")
	private String deleteProduct(@PathVariable int id)
	{
		serv.deleteProduct(serv.getProductById(id));
		return "redirect:/";
	}
}
