package com.example.firstapp.Repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.firstapp.models.Product;

public interface ProductsRepository extends JpaRepository<Product, Integer> {

}
