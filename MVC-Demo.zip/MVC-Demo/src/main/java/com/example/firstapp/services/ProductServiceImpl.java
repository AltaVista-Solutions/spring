package com.example.firstapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.firstapp.Repos.ProductsRepository;
import com.example.firstapp.models.Product;

public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductsRepository repo;
	
	@Override
	public Product addProduct(Product prod) {		
		return repo.save(prod);
	}

	@Override
	public Product updateProduct(Product prod) {
		return repo.save(prod);
	}

	@Override
	public void deleteProduct(Product prod) {
		repo.delete(prod);
	}

	@Override
	public Product getProductById(int id) {
		return repo.findById(id).get();
	}

	@Override
	public List<Product> getAllProducts() {
		return repo.findAll();
	}

}
