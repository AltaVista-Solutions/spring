package com.sample;

public class HDFC implements Bank {
	
	private double ROI;
	private String Country;	
	
	

	public HDFC(double rOI, String country) {
		super();
		ROI = rOI;
		Country = country;
	}

	


	@Override
	public String toString() {
		return "HDFC [ROI=" + ROI + ", Country=" + Country + "]";
	}




	@Override
	public void GetROI() {
		System.out.println("This is From HDFC Bank");
		
	}

}
