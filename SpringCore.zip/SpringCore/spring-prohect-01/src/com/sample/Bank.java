package com.sample;

public interface Bank {
	void GetROI();
}
