package com.sample;

public class Department {
	@Override
	public String toString() {
		return "Department [Did=" + Did + ", Dname=" + Dname + "]";
	}
	private int Did;
	private String Dname;
	public int getDid() {
		return Did;
	}
	public void setDid(int did) {
		Did = did;
	}
	public String getDname() {
		return Dname;
	}
	public void setDname(String dname) {
		Dname = dname;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Department(int did, String dname) {
		super();
		Did = did;
		Dname = dname;
	}
	
	
}
