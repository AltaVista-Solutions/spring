package com.sample;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

	@Bean
	public Department getDepartment()
	{
		return new Department(9001,"IT-DEV");
	}
	
	@Bean
	public Employee getEmployee()
	{
		return new Employee(101,"John",65000,this.getDepartment());
	}
}
