package com.sample;

import org.springframework.stereotype.Component;

@Component
public class CITI implements Bank{

	private double ROI;
	private String Country;	
	
	
	public CITI() {
		super();
		// TODO Auto-generated constructor stub
	}




	public CITI(double rOI, String country) {
		super();
		ROI = rOI;
		Country = country;
	}

	


	@Override
	public String toString() {
		return "CITI [ROI=" + ROI + ", Country=" + Country + "]";
	}




	@Override
	public void GetROI() {
		System.out.println("This is from CITI Bank");
		
	}

}
